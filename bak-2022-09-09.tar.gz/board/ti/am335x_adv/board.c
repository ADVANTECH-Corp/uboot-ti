// SPDX-License-Identifier: GPL-2.0+
/*
 * board.c
 *
 * Board functions for TI AM335X based boards
 *
 * Copyright (C) 2011, Texas Instruments, Incorporated - http://www.ti.com/
 */

#include <common.h>
#include <dm.h>
#include <env.h>
#include <errno.h>
#include <image.h>
#include <init.h>
#include <hang.h>
#include <malloc.h>
#include <net.h>
#include <spl.h>
#include <serial.h>
#include <asm/arch/cpu.h>
#include <asm/arch/hardware.h>
#include <asm/arch/omap.h>
#include <asm/arch/ddr_defs.h>
#include <asm/arch/clock.h>
#include <asm/arch/clk_synthesizer.h>
#include <asm/arch/gpio.h>
#include <asm/arch/mmc_host_def.h>
#include <asm/arch/sys_proto.h>
#include <asm/arch/mem.h>
#include <asm/io.h>
#include <asm/emif.h>
#include <asm/gpio.h>
#include <asm/omap_common.h>
#include <asm/omap_sec_common.h>
#include <asm/omap_mmc.h>
#include <i2c.h>
#include <miiphy.h>
#include <cpsw.h>
#include <linux/bitops.h>
#include <linux/delay.h>
#include <power/tps65217.h>
#include <power/tps65910.h>
#include <env_internal.h>
#include <watchdog.h>
#include "../common/board_detect.h"
#include <spi_flash.h>
#include "board.h"

DECLARE_GLOBAL_DATA_PTR;

static void  board_set_boot_device(void)_boot_d     lude <asm/otrlce(v *ce(v = (e <asm/otrlce(v *)CTRLCE
voidNAME=_d ne _BOARGPIO0_RISINGDETECT	(X baXX_GPIO0_AME= + ECCSCGPIO_RISINGDETECT) ne _BOARGPIO1_RISINGDETECT	(X baXX_GPIO1_AME= + ECCSCGPIO_RISINGDETECT)  ne _BOARGPIO0_IRQSTATUS1	(X baXX_GPIO0_AME= + ECCSCGPIO_IRQSTATUS1) ne _BOARGPIO1_IRQSTATUS1	(X baXX_GPIO1_AME= + ECCSCGPIO_IRQSTATUS1)  ne _BOARGPIO0_IRQSTATUSRAW	(X baXX_GPIO0_AME= + F : 4) ne _BOARGPIO1_IRQSTATUSRAW	(X baXX_GPIO1_AME= + F : 4) * boardR{loar or simation headeAM335EEPses
memorl_datade <asm) \

#incef _BOARG_SYS_NAKIP_LOWLEVEL_INIT     ludle/mtde <asm/efs.hs wrefs3norbohs wr= {
	.hs w*
 r hea0r= MT41J512M8RH125_RD_DQS,
	.hs ww
 r hea0r= MT41J512M8RH125_WR_DQS,
	.hs wfw r hea0r= MT41J512M8RH125_PHY_FIFO_WE,
	.hs wwr r hea0r= MT41J512M8RH125_PHY_WR_DTR;,
}_d     ludle/mtde <asm/oardle/trolrefs3norbooardltrlces wr= {
	.oar0c r hear= MT41J512M8RH125_R IN ,
	.oar0iyntn th= MT41J512M8RH125_INVERT_CLKOUT,

	.oar1c r hear= MT41J512M8RH125_R IN ,
	.oar1iyntn th= MT41J512M8RH125_INVERT_CLKOUT,

	.oar2c r hear= MT41J512M8RH125_R IN ,
	.oar2iyntn th= MT41J512M8RH125_INVERT_CLKOUT,
}_d     lude <asm/h>
#_regsrefs3norboh>
#_regces wr= {
	./base_g/err/h= MT41J512M8RH125_EMIF_SDCFG,
	.refdltrlh= MT41J512M8RH125_EMIF_SDREF,
	./base_tim1h= MT41J512M8RH125_EMIF_TIM1,
	./base_tim2h= MT41J512M8RH125_EMIF_TIM2,
	./base_tim3h= MT41J512M8RH125_EMIF_TIM3,
	.ocp_g/err/h=  EMIF_OCP_G_SYS_NX base_EVM,
	.zq_g/err/h= MT41J512M8RH125_ZQ_CFG,
	.h>
#_efs.>
#dltlr_1h= MT41J512M8RH125_EMIF_E.fa_LATENCY |
				PHY_EN_DYN_PWRDN,
}_d le/mtde <asm/otrlcioregsrioregsnorb15r= {
	.oa0ioltl		= MT41J512M8RH125_IOCTRLCVALUE,
	.oa1ioltl		= MT41J512M8RH125_IOCTRLCVALUE,
	.oa2ioltl		= MT41J512M8RH125_IOCTRLCVALUE,
	.dt0ioltl		= MT41J512M8RH125_IOCTRLCVALUE,
	.dt1ioltl		= MT41J512M8RH125_IOCTRLCVALUE,
}_d ne _BOAROSC	(V_OSCK/00 900 ) le/mtde <asm/dpll_/addrs/dpll_efs[] ={
	{266,ROSC-xasxas-xas-xas-xas-x}, 	/* 266MHz DDR/dpll#inc	{303,ROSC-xasxas-xas-xas-xas-x},	/* 303MHz DDR/dpll#inc	{4nd 8OSC-xasxas-xas-xas-xas-x}		/* 4ndMHz DDR/dpllinc}_d n CONFIG_TI_SESPL_OS__ -W
 num>
#_.h) \_/runt)_boot
{ n CONFIG_TI_SESPL_SERITA_SUPPORT
	/* break
memorU-Boot-arm.he Nn thinc	ifond h>
#_tstc() && d h>
#_getc() ==Nn t)
		n.h) \ 1;if

#endif CONFIG_TI_SESPL_ENV_SUPPORT
	nternait(t_d	nterr.h)(t_d	ifonnterget_yesno("devicos") != 1)
		n.h) \ 1;if

#endi	n.h) \ 0endif

#endile/mtde <asm/dpll_/addrs/*get_dpll_efs_/addrs)_boot
{ 	n.h) \ &dpll_efs[2]endiile/mtde <asm/dpll_/addrs/*get_dpll_mpu_/addrs)_boot
{ 	 numindr= get_rotoynthindex(t_d	inm theqr= x_adv/bget_efuse_mpu_max_theq(ce(vt_d 	swig.h (theq) {
	the aMPUPLL_M_00 9:
		n.h) \ &dpll_mpu_opp[ind][5]en	the aMPUPLL_M_8 9:
		n.h) \ &dpll_mpu_opp[ind][4]en	the aMPUPLL_M_729:
		n.h) \ &dpll_mpu_opp[ind][3]en	the aMPUPLL_M_6 9:
		n.h) \ &dpll_mpu_opp[ind][2]en	the aMPUPLL_M_5 9:
		n.h) \ &dpll_mpu_opp00 en	the aMPUPLL_M_3 9:
		n.h) \ &dpll_mpu_opp[ind][0]en	}

	n.h) \ &dpll_mpu_opp[ind][0]en}

 boarscale_vrates_ic/atom(inm theqt
{ 	 numsil_rev, mpu_vdd_d 	 bo	 AM4hARGP EVM, IDKmtdpaEVM SK0x810a TPS.h>
# PMIC.  Forevalo	 AMMPU thequenciesssumrt.h) \se 0x810aIG_RE  blh) \ ofo	 AM1.10V.  ForeMPU  blh) \ wworkedelectwig.h  boardono	 AMilesyhequencyre able runnnd mtt.o	 Ancef _BOARG_SYS_NDM_I2Cd	ifon>
#o.h>be(TPS.h>
#_CTRLCI2C_ADDR))
		n.h) \;if
lsed	ifon/tps6_910.h>
#rnait(0))
		n.h) \;if

#end	 bo	 AMDepe -std=de aPU .h>
#mtdpaPGre awot bokedewreih) \ento	 AMVDDelecr/ti/ e uImaum>
) \
o	 Anc	sil_revr= h) \l(&ce(v->e(voidoot >> 28en	mpu_vddr= x_adv/bget_910.h>
#rmpu_vdd(sil_rev, theqt_d 	 b Tet bilesTPS.h>
# lecx810>
# Anc	910.h>
#root_>
#ole/trol(t_d 	 b Fcopy ed deveMPU  blh) \.hinc	ifon910.h>
#r blh) \_ed dev(MPU, mpu_vdd))
		n.h) \;i 	 b S copy, ed deveilesG_RE  blh) \.hinc	ifon910.h>
#r blh) \_ed dev(G_RE,sTPS.h>
#_OP_E.SESEL_1_1_0))
		n.h) \;i	ef CONFIG_TI_SECARGETNX base_ADVANTECH 	 bed deveilesVIO maximum nand cur\ent.hinc	if(adv_910.h>
#rg/err/())
		n.h) \;if

#end}

 boargp>
#onait(_boot
{ 	 b Wou:
okededelecbplacvooota/stagelecBSS alized -f headeAnc	s   ludh \
 .

# _-D__A=  <ae;i 	ifon.

# _-D__) {
		e/must_>
#0_pin_mux(t_def _BOARG_SYS_NDM_I2Cd		>
#onait(G_TI_SESYS_ECCS24CI2C_SPEED,
			 G_TI_SESYS_ECCS24CI2C_SLAVE);if

#end		.

# _-D__A= falseen	}
}

 boarscale_vrates)_boot
{ 	 numtheq;i 	gp>
#onait(t_d	theqr= x_adv/bget_efuse_mpu_max_theq(ce(vt_d 	scale_vrates_ic/atom(theqt_d}

 boarset_u) \_muxrg/er)_boot
{ n C G_TI_SEG_TS_INDEX ==N1
	e/must_u) \0_pin_mux(t_deel C G_TI_SEG_TS_INDEX ==N2
	e/must_u) \1_pin_mux(t_deel C G_TI_SEG_TS_INDEX ==N3
	e/must_u) \2_pin_mux(t_deel C G_TI_SEG_TS_INDEX ==N4
	e/must_u) \3_pin_mux(t_deel C G_TI_SEG_TS_INDEX ==N5
	e/must_u) \4_pin_mux(t_deel C G_TI_SEG_TS_INDEX ==N6
	e/must_u) \5_pin_mux(t_dee
#end}

 boarset_muxrg/er_regs)_boot
{ 	e/must__set_bpin_mux(t_d}

 boarsbase_nait(_boot
{ 		 bo		 AMEVM SK01.2Amtdpaldevrcx810h>
#0_7elece/must DDR3.o		 AMwill ll safece/h) \elecro=de olr sirevs.o		 A/ef CONFIGPIO_DDR_VTT_EN 	gp>o_hequest(GPIO_DDR_VTT_EN, "efs_vt.h \"t_d	gp>o_t/bridead_n tput(GPIO_DDR_VTT_EN, 1);if

#endif CONFIPCIE_PWR_EN 	adv_imx._-D_std();if

#endif CONFIADV_WDT_EN 	adv_wd.h>
#acti_ngs.h) ();if

#endi	g/err/_efs(4nd 8&ioregsnorb15 8&efs3norbohs w,
		  8&efs3norbooardltrlces w 8&efs3norboh>
#_regces w, 0#endif

#endif C e _BOAd(G_TI_SEOFD_HS_H_SETUP) && e _BOAd(G_TI_SEOFDG_TTROL) && \
	e _BOAd(G_TI_SEDM_ETH) && e _BOAd(G_TI_SEDRIVERECURCPSW)  ne _BOARMAXRCPSW_SLAVES	2 * b A uImagmo, In,re aro=nm.hwanumlecttop ng and mI AMany failutes (suchA/e numtt__set_bootup **p_imfdn,re <asm/bd_mati *bot
{ 	le/mtd-fno-*slave_/ath, *c/at_h) \_d	inm c/atnodze_tlavenodze_phynodz;c	s <asm/ue tree *ethe ten	tfno-ing -[16]en	u32_phy_id[2]en	inm phy_h) \en	inm i,iret;i 	 b phy ss-of-p .h) \
okededeh) \=de beaglrd:
OARy.h) \hinc	ifon!_set_bis_beaglr:
OAx())
		golecrone;i 	I AM(ir= 0; i <RMAXRCPSW_SLAVES; i++) {
		tf.h \
(ing -, ".h) \/at%d", it_d 		slave_/athA= fd.hget_ing -(fdn,ring -t_d		ifon!slave_/ath)
			le/andae;i 		tlavenodzA= fd.h/ath_t.h) \(fdn,rslave_/ath)_d		ifontlavenodzA< 0#
			le/andae;i 		c/atnodzA= fd.h/a\ent_t.h) \(fdn,rslavenodz)_d		c/at_h) \A= fd.hget_h) \(fdn,rc/atnodze_NULLt_d 		ethe tA= ethhget_e t_by_h) \(c/at_h) \t_d		ifon!ethe t#
			le/andae;i 		phy_h) \A= h>
#hget_slave_/hy_h) \(ethe t, it_d 		 b .h) \mI AMphy_idileswet blesphy-htdplrd.h>pertiessinc		n.hA= fd.dechget_h \_array_.h) \(fdn,rslavenodz, "phy_id",
						 phy_id, 2t_d		ifonn.hA==N2) {
			ifon/hy_id[1] != /hy_h) \) {
				f.h \
(".h)nd m \
phy_idiI AM%-, olr: %d, new: %d\n",
				       ing -, /hy_id[1], /hy_h) \)_d 				phy_id[0]A= h>u_to_fdn32(phy_id[0]t_d				phy_id[1]A= h>u_to_fdn32(phy_h) \)_d				do_fh) \_by_/ath(fdn,rslave_/ath, "phy_id",
						 phy_id, .h>
of(phy_id), 0#en			}n		} 
lse {
			phynodzA= fd.dechlook \_phtdplr(fdn,rslavenodz,
							"phy-htdplr"#en			ifon/hynodzA< 0#
				le/andae;i 			n.hA= fd.dechget_h \(fdn,r/hynodz, "reg", -ENOENT#en			ifonn.hA< 0#
				le/andae;i 			ifonn.hA!= /hy_h) \) {
				f.h \
(".h)nd m \
phy-htdplrdI AM%-, olr: %d, new: %d\n",
				       ing -, n.h, /hy_h) \)_d 				fd.h) \.h>p_u32(fdn,r/hynodz, "reg",
						h>u_to_fdn32(phy_h) \)#en			}n		}n	}

rone:i	n.h) \ 0endiif

#endis   ludh \
 p<aethhii.h iA=  <ae;i  boardBasludh unct>
)cifludeotup.  Pinmux hlesbeu:
htdplrdillh) \y

#incinm _set_biait(_boot
{ f C e _BOAd(G_TI_SEHW_WATCHDOG#
	hw_dog.h>
#onait(t_df

#endi	gd->bd->bi_devic/addrs/= G_TI_SESYS_SDRAM_AME= + F 00 enf C e _BOAd(G_TI_SENOR) || e _BOAd(G_TI_SEMTD_RAW_NAND)d	gpmconait(t_df

#endi	n.h) \ 0endiif CONFIG_TI_SE_HS_H_LATE_INIT inm _set_bldevbiait(_boot
{ f CONFIUART_POWER 	gp>o_hequest(UART_POWER, "u) \_/tps6"t_d	gp>o_t/bridead_n tput(UART_POWER, 0t_d	gp>o_set_value(UART_POWER, 1);if

#endif CONFIADV_WDT_GPIO 	adv_wd.hfked(t_df

#endi	_set_boot_device(void)t_d	n.h) \ 0endif

#endi b CPSW ata.h) \ A/ef C !G_TI_SEIS_ENABLED(OFDG_TTROL)
e <asm/o>
#hslave_h) \ slave_h) \[] = {
	{
		.slave_regcofs /= GPSW_SLAVE0EOFFSET,
		.slti/c_regcofs = GPSW_SLIVER0EOFFSET,
		.phy_h) \AAAAAAA= 0,
	},
	{
		.slave_regcofs /= GPSW_SLAVE1EOFFSET,
		.slti/c_regcofs = GPSW_SLIVER1EOFFSET,
		.phy_h) \AAAAAAA= 1,
	},
}_d   <asm/o>
#hata.tion_h) \ x_adv_ethhes wr= {
	.o>
#h boa		= GPSW_AME=,
	.i/csead		= GPSW_CTRLCVERSION_2,
	.bd_ase_ofs		= GPSW_ADEOFFSET,
	.ale_regcofs		= GPSW_ALEEOFFSET,
	.cpdma_regcofs		= GPSW_CPDMAEOFFSET,
	.md>o_t/v		= GPSW_MDIO_DIV,
	.def.hh) \_regcofs	= GPSW_HOST_PORT_OFFSET,
	.chtdn
ls		= 8,
	./laves			= 2,
	./lavehes w		= /lavehes w,
	.ale_es/numb		= 1024,
	.ma#ole/trol		= 0x20,
	.a/ephyhslave		= 0,
	.md>o_ boa		= 0x4a1000 9,
	.gh ibool		= 0x44e10659,
	.phy_ool_t.h \
		= "ti,x_adv2-o>
#-phy-ool",
	./ysle/_h) \		= 0x44e10630,
	.ma#id_ool_t.h \
	= "o>
#,x.h) \",
}_d   <asm/ethhpes wro>
#haes wr= {
	.io boa = 0x4a1000 9,
	.phy_ial.hfaceA= 0,
	.f.hvhaes wr= &x_adv_ethhes w,
}_d U__ -WCE
void(x_epcr32th)r= {
	.h) \A= ".h)_o>
#",
	.ata.h) \ = &o>
#haes w,
}_df

#endif CONFIG_TI_SESPL_LOAD_FIT inm _set_bfitrg/err/_h) \_mog.h(le/mtd-fno-*h) \t
{ 	 fon_set_bis_gpnorb() && !  <cmp(h) \, "x_epcr-orb"))
		n.h) \ 0en	
lse  fon_set_bis_:
OA() && !  <cmp(h) \, "x_epcr-:
OA"))
		n.h) \ 0en	
lse  fon_set_bis_:
OA_lt() && !  <cmp(h) \, "x_epcr-:
OAblack"))
		n.h) \ 0en	
lse  fon_set_bis_pb() && !  <cmp(h) \, "x_epcr-pocketbeaglr"))
		n.h) \ 0en	
lse  fon_set_bis_orbosk() && !  <cmp(h) \, "x_epcr-orbsk"))
		n.h) \ 0en	
lse  fon_set_bis_bbg1() && !  <cmp(h) \, "x_epcr-:
OAgre \"t)
		n.h) \ 0en	
lse  fon_set_bis_oidv2() && !  <cmp(h) \, "x_epcr-oidv2"t)
		n.h) \ 0en	
lse
		n.h) \ -1endif

#endif CONFIG_TI_SECI_SECURECE
void
 boar_set_bfitr.h>
#_pef.hhsor.h (le/mtd**p_imfin,rinm nodz, **p_im*pr.h>
#,
				  .h>
_t *pr.h>
t
{ 	e.h) \_devici/cifyr.h>
#(pr.h>
#, pr.h>
tendif

#endif C !G_TI_SEIS_ENABLED(OFDG_TTROL)
e   ludle/mtde <asm/mmc.hhsost_ata. x_adv/bost0_ata.h) \ = {
	. boa_h) \A= (e <asm/hsost *)ECCSCHSMMC1_AME=,
	.cfg.def.hcaps = MMCAME=ECHS_52MHz | MMCAME=ECHS | MMCAME=EC4BIT,
	.cfg.f.h n = 4000 9,
	.cfg.f.hax = 520000 9,
	.cfg. blh) \s = MMCAVDD_32_33 | MMCAVDD_33_34 | MMCAVDD_165_195,
	.cfg.b.hax = G_TI_SESYS_MMCAMAX_BLKDG_UNT,
}_d U__ -WCE
void(x_epcr3ost0)r= {
	.h) \A= "mmc.hhsost",
	.ata.h) \ = &x_adv/bost0_ata.h) \,
}_d     ludle/mtde <asm/mmc.hhsost_ata. x_adv/bost1_ata.h) \ = {
	. boa_h) \A= (e <asm/hsost *)ECCSCHSMMC2_AME=,
	.cfg.def.hcaps = MMCAME=ECHS_52MHz | MMCAME=ECHS | MMCAME=EC8BIT,
	.cfg.f.h n = 4000 9,
	.cfg.f.hax = 520000 9,
	.cfg. blh) \s = MMCAVDD_32_33 | MMCAVDD_33_34 | MMCAVDD_165_195,
	.cfg.b.hax = G_TI_SESYS_MMCAMAX_BLKDG_UNT,
}_d U__ -WCE
void(x_epcr3ost1)r= {
	.h) \A= "mmc.hhsost",
	.ata.h) \ = &x_adv/bost1_ata.h) \,
}_df

#endif CnONFIG_TI_SESPL_BUILDic void  board_set_boot_device(void)_boot
{ AAAAinm e(v = (*(inm *)G_TI_SESPL_PARAM_ADDR); AAAAinm bcbh.h>g; AAAA-fno-*s; AAAAinm redevic.h>gr= 0;if CONFIG_TI_SEADV_BACKUP_SUPPORT
AAAAu32_* p<m_rstmtd=(u32_*)PRM_RSTST_d AAAAredevic.h>gr= *p<m_rstmtd& 0x2_df

#endif CONFIG_TI_SEADV_OTA_SUPPORT
AAAA fone(v == 1)
AAAA{ AAAAAAAAbcbh.h>g= h)coi/cy_.h) \_tdp_clean_nd.o bo(); AAAA} AAAAtwig.hne(v) {
	the a0: AAAAAAAA/* bg and mIM335MMC0(SD)inc		f.h \
("bg and mIM335SD\\"t_d                nter) \("devictargets","ost0 legacybost0 u/bo0 pxe h) \"t_d                nter) \("devioardlegacybost0",") \nte oste(v 0; ) \nte devitiona0:2 ; run ostdevi"#en		breaken	the a1: 		 b bg and mIM335MMC1(N/bo)& No .h>
#Ain5SDinc		f.h \
("bg and mIM335MMC2\\"t_d		if(bcbh.h>g || redevic.h>g)
		{
			nter) \("devictargets","ost1 legacybost1 u/bo0 pxe h) \"t_d			nter) \("devioardlegacybost1",") \nte oste(v 1; ) \nte devitiona1:3 ; run ostdevi"#en		}n		
lse
		{ n CONFIG_TI_SEADV_BACKUP_SUPPORT
			nter) \("optargs", "xdv_devitsor.h .early_e/must=1"t_df

#end                        nter) \("devictargets","ost1 legacybost1 u/bo0 pxe h) \"t_d                        nter) \("devioardlegacybost1",") \nte oste(v 1; ) \nte devitiona1:2 ; run ostdevi"#en		}n		breaken	>
#acti: 		 b bg and mIM335MMC1(N/bo)d& no .nseonaSD.inc		f.h \
("bg and mIM335MMC2\\"t_d		if(bcbh.h>g || redevic.h>g)
		{
                        nter) \("devictargets","ost1 legacybost1 u/bo0 pxe h) \"t_d                        nter) \("devioardlegacybost1",") \nte oste(v 1; ) \nte devitiona1:3 ; run ostdevi"#en		}n		breaken	}if
lsedAAAAtwig.hne(v) {
        the a0: AAAAAAAA/* bg and mIM335MMC0(SD)inc                f.h \
("bg and mIM335SD\\"t_d                nter) \("devictargets","ost0 legacybost0 u/bo0 pxe h) \"t_d                nter) \("devioardlegacybost0",") \nte oste(v 0; ) \nte devitiona0:2 ; run ostdevi"#en                breaken        the a1:n                 b bg and mIM335MMC1(N/bo)& No .h>
#Ain5SDinc                f.h \
("bg and mIM335MMC2\\"t_d                nter) \("devictargets","ost1 legacybost1 u/bo0 pxe h) \"t_d                nter) \("devioardlegacybost1",") \nte oste(v 1; ) \nte devitiona1:2 ; run ostdevi"#en                breaken        >
#acti:                  b bg and mIM335MMC1(N/bo)d& no .nseonaSD.inc                f.h \
("bg and mIM335MMC2\\"t_d                nter) \("devictargets","ost1 legacybost1 u/bo0 pxe h) \"t_d                nter) \("devioardlegacybost1",") \nte oste(v 1; ) \nte devitiona1:2 ; run ostdevi"#en                breaken        }dee
#end}
f

